#!/bin/bash
time ./urlRewriter input.json <test.list >result.txt
